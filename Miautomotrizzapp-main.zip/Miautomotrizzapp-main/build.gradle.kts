plugins {
    alias(libs.plugins.android.application) apply false
    // Mueve la línea aquí adentro:
    id("com.google.gms.google-services") version "4.4.0" apply false
}
