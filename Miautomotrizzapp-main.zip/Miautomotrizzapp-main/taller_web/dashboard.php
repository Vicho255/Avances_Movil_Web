<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Taller Automotriz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">🏁 Taller Automotriz - Panel de Control</span>
    </div>
</nav>

<div class="container">
    
    <div class="row mb-5">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold">💰 Costos por Reparación (Barras)</div>
                <div class="card-body">
                    <canvas id="graficoBarras"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold">📊 Estado de Solicitudes (Torta)</div>
                <div class="card-body">
                    <canvas id="graficoTorta"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Listado de Reparaciones</h5>
            <input type="text" id="inputFiltro" class="form-control w-25" placeholder="🔍 Buscar por patente...">
        </div>
        <div class="card-body">
            <table class="table table-hover table-bordered" id="tablaReparaciones">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Patente</th>
                        <th>Descripción</th>
                        <th>Fecha</th>
                        <th>Costo</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody id="cuerpoTabla">
                    </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // 1. Cargar datos al iniciar
    fetch('datos.php')
        .then(response => response.json())
        .then(data => {
            cargarGraficos(data);
            cargarTabla(data.tabla);
        });

    // 2. Función para crear los gráficos
    function cargarGraficos(data) {
        // Gráfico de Barras
        new Chart(document.getElementById('graficoBarras'), {
            type: 'bar',
            data: {
                labels: data.barras.labels,
                datasets: [{
                    label: 'Costo ($)',
                    data: data.barras.data,
                    backgroundColor: '#36A2EB'
                }]
            }
        });

        // Gráfico de Torta
        new Chart(document.getElementById('graficoTorta'), {
            type: 'pie',
            data: {
                labels: data.torta.labels,
                datasets: [{
                    data: data.torta.data,
                    backgroundColor: ['#FF6384', '#4BC0C0', '#FFCE56']
                }]
            }
        });
    }

    // 3. Función para llenar la tabla
    function cargarTabla(datosTabla) {
        let html = '';
        datosTabla.forEach(fila => {
            // Pintar estado según valor
            let colorEstado = fila.estado === 'Aprobado' ? 'text-success fw-bold' : 'text-danger';
            
            html += `<tr>
                        <td>${fila.id}</td>
                        <td>${fila.patente}</td>
                        <td>${fila.descripcion}</td>
                        <td>${fila.fecha}</td>
                        <td>$${fila.costo}</td>
                        <td class="${colorEstado}">${fila.estado}</td>
                     </tr>`;
        });
        document.getElementById('cuerpoTabla').innerHTML = html;
    }

    // 4. Lógica de FILTRO JS (Requisito)
    document.getElementById('inputFiltro').addEventListener('keyup', function() {
        let texto = this.value.toLowerCase();
        let filas = document.querySelectorAll('#cuerpoTabla tr');

        filas.forEach(fila => {
            let textoFila = fila.innerText.toLowerCase();
            if (textoFila.includes(texto)) {
                fila.style.display = '';
            } else {
                fila.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>