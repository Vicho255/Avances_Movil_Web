<?php
include 'conexion.php';

// 1. DATOS PARA GRÁFICO DE BARRAS (Costos por Reparación)
$queryBarras = "SELECT descripcion, costo FROM reparaciones LIMIT 5";
$resBarras = mysqli_query($conexion, $queryBarras);

$labelsBarras = [];
$dataBarras = [];

while ($fila = mysqli_fetch_assoc($resBarras)) {
    $labelsBarras[] = $fila['descripcion']; // Nombres (ej: Cambio Aceite)
    $dataBarras[] = $fila['costo'];         // Precios (ej: 45000)
}

// 2. DATOS PARA GRÁFICO DE TORTA (Estados: Pendiente vs Aprobado)
$queryTorta = "SELECT estado, COUNT(*) as cantidad FROM reparaciones GROUP BY estado";
$resTorta = mysqli_query($conexion, $queryTorta);

$labelsTorta = [];
$dataTorta = [];

while ($fila = mysqli_fetch_assoc($resTorta)) {
    $labelsTorta[] = $fila['estado'];
    $dataTorta[] = $fila['cantidad'];
}

// 3. DATOS PARA LA TABLA (Lista completa)
$queryTabla = "SELECT * FROM reparaciones";
$resTabla = mysqli_query($conexion, $queryTabla);
$filasTabla = [];
while ($fila = mysqli_fetch_assoc($resTabla)) {
    $filasTabla[] = $fila;
}

// Empaquetamos todo en un solo JSON para la vista
$respuesta = [
    "barras" => ["labels" => $labelsBarras, "data" => $dataBarras],
    "torta" => ["labels" => $labelsTorta, "data" => $dataTorta],
    "tabla" => $filasTabla
];

echo json_encode($respuesta);
?>