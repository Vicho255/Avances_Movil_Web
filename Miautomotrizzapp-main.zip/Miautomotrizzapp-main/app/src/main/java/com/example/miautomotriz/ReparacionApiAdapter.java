package com.example.miautomotriz;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * Adaptador para RecyclerView.
 * Se encarga de convertir la lista de objetos 'Reparacion' en vistas visuales (Tarjetas).
 * Incluye lógica de filtrado y acciones de botones.
 */
public class ReparacionApiAdapter extends RecyclerView.Adapter<ReparacionApiAdapter.ViewHolder> {

    private List<Reparacion> listaOriginal; // Copia completa para restaurar tras filtrar
    private List<Reparacion> listaFiltrada; // La lista que realmente se ve en pantalla
    private OnItemClickListener listener;   // Interfaz para comunicar clicks a la Actividad
    private Context context;                // Contexto necesario para lanzar Intents (Compartir)

    // Interfaz para manejar el click en "Aprobar"
    public interface OnItemClickListener {
        void onAprobarClick(String id);
    }

    public ReparacionApiAdapter(List<Reparacion> lista, OnItemClickListener listener) {
        this.listaOriginal = lista;
        this.listaFiltrada = new ArrayList<>(lista);
        this.listener = listener;
    }

    /**
     * Lógica del Buscador: Filtra la lista según la Patente ingresada.
     */
    public void filtrar(String texto) {
        listaFiltrada.clear();
        if (texto.isEmpty()) {
            // Si no hay texto, mostramos todo
            listaFiltrada.addAll(listaOriginal);
        } else {
            // Buscamos coincidencias
            for (Reparacion r : listaOriginal) {
                if (r.getPatente().toLowerCase().contains(texto.toLowerCase())) {
                    listaFiltrada.add(r);
                }
            }
        }
        notifyDataSetChanged(); // Avisamos a Android que actualice la pantalla
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        // Inflamos el diseño de la tarjeta (item_reparacion_api.xml)
        View view = LayoutInflater.from(context).inflate(R.layout.item_reparacion_api, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Reparacion r = listaFiltrada.get(position);

        // Asignamos datos a los textos
        holder.tvPatente.setText(r.getPatente());
        holder.tvDesc.setText(r.getDescripcion());
        holder.tvCosto.setText("$" + r.getCosto());
        holder.tvEstado.setText(r.getEstado());

        // LOGICA VISUAL: Si ya está aprobado, deshabilitamos el botón
        if (r.getEstado().equalsIgnoreCase("Aprobado")) {
            holder.btnAprobar.setEnabled(false);
            holder.btnAprobar.setText("Listo");
            holder.btnAprobar.setBackgroundColor(0xFF81C784); // Verde
        } else {
            holder.btnAprobar.setEnabled(true);
            holder.btnAprobar.setText("Aprobar");
            holder.btnAprobar.setBackgroundColor(0xFF1976D2); // Azul

            // Evento click para Aprobar
            holder.btnAprobar.setOnClickListener(v -> listener.onAprobarClick(r.getId()));
        }

        // Evento click para Compartir (WhatsApp/Correo)
        holder.btnCompartir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                compartirCotizacion(r);
            }
        });
    }

    /**
     * Crea un Intent implícito para compartir el texto de la cotización
     * con otras aplicaciones (WhatsApp, Gmail, etc).
     */
    private void compartirCotizacion(Reparacion r) {
        String mensaje = "🔧 *Cotización Taller Automotriz* \n\n" +
                "🚗 Patente: " + r.getPatente() + "\n" +
                "📋 Detalle: " + r.getDescripcion() + "\n" +
                "💰 Total: $" + r.getCosto() + "\n\n" +
                "Estado: " + r.getEstado();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, mensaje);
        // Muestra el selector de apps de Android
        context.startActivity(Intent.createChooser(intent, "Compartir vía:"));
    }

    @Override
    public int getItemCount() { return listaFiltrada.size(); }

    // Clase interna que vincula los IDs del XML
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatente, tvDesc, tvCosto, tvEstado;
        Button btnAprobar;
        ImageButton btnCompartir;

        public ViewHolder(View view) {
            super(view);
            tvPatente = view.findViewById(R.id.tvPatenteApi);
            tvDesc = view.findViewById(R.id.tvDescApi);
            tvCosto = view.findViewById(R.id.tvCostoApi);
            tvEstado = view.findViewById(R.id.tvEstadoApi);
            btnAprobar = view.findViewById(R.id.btnAprobarApi);
            btnCompartir = view.findViewById(R.id.btnCompartirApi);
        }
    }
}