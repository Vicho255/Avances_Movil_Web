package com.example.miautomotriz;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    // 1. Guardar Vehículo (JSON)
    @POST("guardar_vehiculo.php")
    Call<Void> registrarVehiculo(@Body Vehiculo vehiculo);

    // 2. Obtener Vehículos (GET)
    @GET("obtener_vehiculos.php")
    Call<List<Vehiculo>> obtenerVehiculos();

    // --- NUEVO PARA ESTA PANTALLA ---

    // 3. Obtener Reparaciones (GET)
    @GET("obtener_reparaciones.php")
    Call<List<Reparacion>> obtenerReparaciones();

    // 4. Agendar Cita (POST con Formulario)
    @FormUrlEncoded
    @POST("agendar_cita.php")
    Call<Void> agendarCita(
            @Field("patente") String patente,
            @Field("descripcion") String descripcion,
            @Field("fecha") String fecha,
            @Field("costo") String costo
    );

    // 5. Aprobar Cotización (POST con Formulario)
    @FormUrlEncoded
    @POST("aprobar_cotizacion.php")
    Call<Void> aprobarCotizacion(@Field("id_reparacion") String id);
}