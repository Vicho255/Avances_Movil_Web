package com.example.miautomotriz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class VehiculoDbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 5; // ¡SUBIMOS A VERSIÓN 5!
    private static final String DATABASE_NAME = "automotriz.db";

    // Tablas
    private static final String TABLE_VEHICULOS = "vehiculos";
    private static final String TABLE_USUARIOS = "usuarios";
    private static final String TABLE_MANTENIMIENTOS = "mantenimientos";
    private static final String TABLE_VENTAS = "ventas"; // NUEVA TABLA

    // Columnas Comunes
    private static final String KEY_ID = "id";

    // Columnas Ventas
    private static final String VENTA_PATENTE = "patente";
    private static final String VENTA_CLIENTE = "cliente";
    private static final String VENTA_FECHA = "fecha";
    private static final String VENTA_MONTO = "monto";

    // Columnas Vehículos (Referencias)
    private static final String KEY_PATENTE = "patente";
    private static final String KEY_ESTADO = "estado";

    // (Omito las constantes de otras tablas para no hacer el código gigante,
    // pero al pegar esto sobreescribe lo anterior, así que mantendré las necesarias)
    private static final String KEY_MARCA = "marca";
    private static final String KEY_MODELO = "modelo";
    private static final String KEY_ANIO = "anio";
    private static final String KEY_TIPO = "tipo";

    // Columnas Usuarios
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Columnas Mantenimientos
    private static final String MANT_ID = "id";
    private static final String MANT_PATENTE = "patente_vehiculo";
    private static final String MANT_FECHA = "fecha";
    private static final String MANT_DESCRIPCION = "descripcion";
    private static final String MANT_COSTO = "costo";


    public VehiculoDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 1. Vehículos
        db.execSQL("CREATE TABLE " + TABLE_VEHICULOS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_PATENTE + " TEXT UNIQUE,"
                + KEY_MARCA + " TEXT,"
                + KEY_MODELO + " TEXT,"
                + KEY_ANIO + " INTEGER,"
                + KEY_TIPO + " TEXT,"
                + KEY_ESTADO + " TEXT" + ")");

        // 2. Usuarios
        db.execSQL("CREATE TABLE " + TABLE_USUARIOS + "("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_USERNAME + " TEXT,"
                + COL_PASSWORD + " TEXT" + ")");
        db.execSQL("INSERT INTO " + TABLE_USUARIOS + " (username, password) VALUES ('admin', '1234')");

        // 3. Mantenimientos
        db.execSQL("CREATE TABLE " + TABLE_MANTENIMIENTOS + "("
                + MANT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + MANT_PATENTE + " TEXT,"
                + MANT_FECHA + " TEXT,"
                + MANT_DESCRIPCION + " TEXT,"
                + MANT_COSTO + " INTEGER" + ")");

        // 4. Ventas (NUEVA)
        db.execSQL("CREATE TABLE " + TABLE_VENTAS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + VENTA_PATENTE + " TEXT,"
                + VENTA_CLIENTE + " TEXT,"
                + VENTA_FECHA + " TEXT,"
                + VENTA_MONTO + " INTEGER" + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICULOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USUARIOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MANTENIMIENTOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VENTAS);
        onCreate(db);
    }

    // --- MÉTODOS ESPECIALES PARA VENTAS ---

    // 1. Obtener SOLO vehículos disponibles (Para el Spinner de Ventas)
    public List<String> getVehiculosDisponibles() {
        List<String> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        // Filtramos por estado 'Disponible'
        Cursor cursor = db.rawQuery("SELECT " + KEY_PATENTE + " FROM " + TABLE_VEHICULOS + " WHERE " + KEY_ESTADO + " = 'Disponible'", null);
        if (cursor.moveToFirst()) {
            do {
                lista.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lista;
    }

    // 2. Registrar Venta Y Actualizar Vehículo (Transacción)
    public void registrarVenta(Venta venta) {
        SQLiteDatabase db = this.getWritableDatabase();

        // A. Insertar la venta
        ContentValues valuesVenta = new ContentValues();
        valuesVenta.put(VENTA_PATENTE, venta.getPatenteVehiculo());
        valuesVenta.put(VENTA_CLIENTE, venta.getCliente());
        valuesVenta.put(VENTA_FECHA, venta.getFecha());
        valuesVenta.put(VENTA_MONTO, venta.getMonto());
        db.insert(TABLE_VENTAS, null, valuesVenta);

        // B. Actualizar el estado del vehículo a 'Vendido'
        ContentValues valuesVehiculo = new ContentValues();
        valuesVehiculo.put(KEY_ESTADO, "Vendido");
        db.update(TABLE_VEHICULOS, valuesVehiculo, KEY_PATENTE + " = ?", new String[]{venta.getPatenteVehiculo()});

        db.close();
    }

    public List<Venta> getAllVentas() {
        List<Venta> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_VENTAS + " ORDER BY " + KEY_ID + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                Venta v = new Venta();
                v.setId(cursor.getInt(0));
                v.setPatenteVehiculo(cursor.getString(1));
                v.setCliente(cursor.getString(2));
                v.setFecha(cursor.getString(3));
                v.setMonto(cursor.getInt(4));
                lista.add(v);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lista;
    }

    // --- MÉTODOS ANTERIORES (Mantener para que todo siga funcionando) ---
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USUARIOS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?", new String[]{username, password});
        boolean existe = cursor.getCount() > 0;
        cursor.close();
        return existe;
    }

    public void addVehiculo(Vehiculo vehiculo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PATENTE, vehiculo.getPatente());
        values.put(KEY_MARCA, vehiculo.getMarca());
        values.put(KEY_MODELO, vehiculo.getModelo());
        values.put(KEY_ANIO, vehiculo.getAnio());
        values.put(KEY_TIPO, vehiculo.getTipo());
        values.put(KEY_ESTADO, vehiculo.getEstado());
        db.insertOrThrow(TABLE_VEHICULOS, null, values);
        db.close();
    }

    public List<Vehiculo> getAllVehiculos() {
        List<Vehiculo> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_VEHICULOS + " ORDER BY " + KEY_ID + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                Vehiculo v = new Vehiculo(Integer.parseInt(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4), cursor.getString(5), cursor.getString(6));
                lista.add(v);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lista;
    }

    public int updateVehiculo(Vehiculo vehiculo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PATENTE, vehiculo.getPatente());
        values.put(KEY_MARCA, vehiculo.getMarca());
        values.put(KEY_MODELO, vehiculo.getModelo());
        values.put(KEY_ANIO, vehiculo.getAnio());
        values.put(KEY_TIPO, vehiculo.getTipo());
        values.put(KEY_ESTADO, vehiculo.getEstado());
        return db.update(TABLE_VEHICULOS, values, KEY_ID + " = ?", new String[]{String.valueOf(vehiculo.getId())});
    }

    public void deleteVehiculo(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_VEHICULOS, KEY_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Método para Spinner de Mantenimientos (Trae todas, vendidas o no)
    public List<String> getAllPatentes() {
        List<String> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + KEY_PATENTE + " FROM " + TABLE_VEHICULOS, null);
        if (cursor.moveToFirst()) {
            do { lista.add(cursor.getString(0)); } while (cursor.moveToNext());
        }
        cursor.close();
        return lista;
    }

    public void addMantenimiento(Mantenimiento mant) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(MANT_PATENTE, mant.getPatenteVehiculo());
        values.put(MANT_FECHA, mant.getFecha());
        values.put(MANT_DESCRIPCION, mant.getDescripcion());
        values.put(MANT_COSTO, mant.getCosto());
        db.insert(TABLE_MANTENIMIENTOS, null, values);
        db.close();
    }

    public List<Mantenimiento> getAllMantenimientos() {
        List<Mantenimiento> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_MANTENIMIENTOS + " ORDER BY " + MANT_ID + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                Mantenimiento m = new Mantenimiento(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getInt(4));
                lista.add(m);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lista;
    }

    public void deleteMantenimiento(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MANTENIMIENTOS, MANT_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}