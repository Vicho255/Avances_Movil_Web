package com.example.miautomotriz;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class ReportesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportes);

        WebView webView = findViewById(R.id.webViewReportes); // Asegúrate de tener un WebView en tu XML

        // Configuración para que funcione bien
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Evita que se abra en Chrome, que se quede dentro de tu App
        webView.setWebViewClient(new WebViewClient());

        // CARGAR TU DASHBOARD
        // Usa la IP de tu PC (ej: 192.168.1.9) si usas celular real
        // O usa 10.0.2.2 si usas el emulador
        String url = "http://10.0.2.2/taller_web/dashboard.php";
        webView.loadUrl(url);
    }
}