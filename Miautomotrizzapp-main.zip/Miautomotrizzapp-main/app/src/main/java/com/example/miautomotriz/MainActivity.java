package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

// Importaciones de Retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VehiculoAdapter adapter;

    // Ya no necesitamos esto porque usaremos Internet
    // private VehiculoDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. (Omitido) Ya no inicializamos dbHelper local

        // 2. Configurar RecyclerView
        recyclerView = findViewById(R.id.recyclerViewVehiculos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 3. Configurar Botón para ir a Agregar
        FloatingActionButton fab = findViewById(R.id.fabAgregar);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AgregarVehiculoActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarListaVehiculos();
    }

    private void cargarListaVehiculos() {
        // --- AQUÍ OCURRE LA MAGIA DE INTERNET ---

        // 1. Configurar Retrofit (Igual que en AgregarVehiculoActivity)
        // CAMBIA ESTO SI USAS CELULAR FÍSICO A TU IP (ej: "http://192.168.1.15/api_automotriz/")
        String url = "http://10.0.2.2/api_automotriz/";

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService service = retrofit.create(ApiService.class);

        // 2. Pedir los datos al archivo obtener_vehiculos.php
        Call<List<Vehiculo>> llamada = service.obtenerVehiculos();

        llamada.enqueue(new Callback<List<Vehiculo>>() {
            @Override
            public void onResponse(Call<List<Vehiculo>> call, Response<List<Vehiculo>> response) {
                if (response.isSuccessful()) {
                    // ¡Éxito! Tenemos la lista del servidor
                    List<Vehiculo> listaDesdeInternet = response.body();

                    // Seguridad por si la lista viene vacía
                    if (listaDesdeInternet == null) {
                        listaDesdeInternet = new ArrayList<>();
                    }

                    // 3. Mostrar en pantalla
                    adapter = new VehiculoAdapter(listaDesdeInternet); // Asegúrate que tu Adapter acepte este constructor
                    recyclerView.setAdapter(adapter);

                } else {
                    Toast.makeText(MainActivity.this, "Error del servidor: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Vehiculo>> call, Throwable t) {
                // Esto pasa si XAMPP está apagado o la IP está mal
                Toast.makeText(MainActivity.this, "Error de conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}