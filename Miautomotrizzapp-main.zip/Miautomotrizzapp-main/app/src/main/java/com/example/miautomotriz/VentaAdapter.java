package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class VentaAdapter extends RecyclerView.Adapter<VentaAdapter.VentaViewHolder> {

    private List<Venta> lista;

    public VentaAdapter(List<Venta> lista) {
        this.lista = lista;
    }

    public static class VentaViewHolder extends RecyclerView.ViewHolder {
        TextView tvCliente, tvPatente, tvMonto, tvFecha;

        public VentaViewHolder(View view) {
            super(view);
            // Buscamos los IDs que pusiste en item_venta.xml
            tvCliente = view.findViewById(R.id.tvVentaCliente);
            tvPatente = view.findViewById(R.id.tvVentaPatente);
            tvMonto = view.findViewById(R.id.tvVentaMonto);
            tvFecha = view.findViewById(R.id.tvVentaFecha);
        }
    }

    @NonNull
    @Override
    public VentaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_venta, parent, false);
        return new VentaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VentaViewHolder holder, int position) {
        Venta v = lista.get(position);
        holder.tvCliente.setText("Cliente: " + v.getCliente());
        holder.tvPatente.setText("Vehículo: " + v.getPatenteVehiculo());
        holder.tvMonto.setText("$" + v.getMonto());
        holder.tvFecha.setText(v.getFecha());
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }
}