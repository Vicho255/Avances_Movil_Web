package com.example.miautomotriz;

public class Mantenimiento {
    private int id;
    private String patenteVehiculo; // Para saber a qué auto pertenece
    private String fecha;
    private String descripcion;
    private int costo;

    public Mantenimiento() { }

    public Mantenimiento(String patenteVehiculo, String fecha, String descripcion, int costo) {
        this.patenteVehiculo = patenteVehiculo;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.costo = costo;
    }

    public Mantenimiento(int id, String patenteVehiculo, String fecha, String descripcion, int costo) {
        this.id = id;
        this.patenteVehiculo = patenteVehiculo;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.costo = costo;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPatenteVehiculo() { return patenteVehiculo; }
    public void setPatenteVehiculo(String patenteVehiculo) { this.patenteVehiculo = patenteVehiculo; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public int getCosto() { return costo; }
    public void setCosto(int costo) { this.costo = costo; }
}