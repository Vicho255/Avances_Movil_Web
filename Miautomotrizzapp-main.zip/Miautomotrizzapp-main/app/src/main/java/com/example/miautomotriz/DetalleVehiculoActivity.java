package com.example.miautomotriz;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

public class DetalleVehiculoActivity extends AppCompatActivity {

    // Usamos TextInputEditText para mejor diseño
    private TextInputEditText etMarca, etModelo, etPatente, etAnio;

    // Usamos AutoCompleteTextView para el menú desplegable del estado
    private AutoCompleteTextView actvEstado;

    private Button btnActualizar, btnEliminar;
    private int vehiculoId;
    private VehiculoDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_vehiculo);

        dbHelper = new VehiculoDbHelper(this);

        inicializarVistas();
        configurarMenuEstado(); // <--- Configurar el desplegable
        recibirDatos();

        // Botón ACTUALIZAR
        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actualizarVehiculo();
            }
        });

        // Botón ELIMINAR
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmarEliminacion();
            }
        });
    }

    private void inicializarVistas() {
        etMarca = findViewById(R.id.etDetalleMarca);
        etModelo = findViewById(R.id.etDetalleModelo);
        etPatente = findViewById(R.id.etDetallePatente);
        etAnio = findViewById(R.id.etDetalleAnio);

        // Este es el desplegable
        actvEstado = findViewById(R.id.actvDetalleEstado);

        btnActualizar = findViewById(R.id.btnActualizar);
        btnEliminar = findViewById(R.id.btnEliminar);
    }

    private void configurarMenuEstado() {
        // Definimos las opciones que aparecerán en la lista
        String[] opcionesEstado = new String[] {"Disponible", "En Mantenimiento", "Vendido", "Reservado"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                opcionesEstado
        );

        actvEstado.setAdapter(adapter);
    }

    private void recibirDatos() {
        if (getIntent().hasExtra("id")) {
            vehiculoId = getIntent().getIntExtra("id", -1);

            // Llenamos los campos con lo que viene de la lista
            etMarca.setText(getIntent().getStringExtra("marca"));
            etModelo.setText(getIntent().getStringExtra("modelo"));
            etPatente.setText(getIntent().getStringExtra("patente"));
            etAnio.setText(String.valueOf(getIntent().getIntExtra("anio", 0)));

            // Seteamos el estado actual.
            // 'false' es para que no se despliegue el menú solo al iniciar
            actvEstado.setText(getIntent().getStringExtra("estado"), false);
        }
    }

    private void actualizarVehiculo() {
        String marca = etMarca.getText().toString();
        String modelo = etModelo.getText().toString();
        String patente = etPatente.getText().toString();
        String anioStr = etAnio.getText().toString();
        String estado = actvEstado.getText().toString(); // Obtenemos lo seleccionado del menú

        if(marca.isEmpty() || anioStr.isEmpty()) {
            Toast.makeText(this, "Por favor completa los datos", Toast.LENGTH_SHORT).show();
            return;
        }

        int anio = Integer.parseInt(anioStr);

        // Creamos objeto actualizado (El tipo lo mantenemos igual por ahora o podrías ponerlo hardcodeado)
        Vehiculo v = new Vehiculo(vehiculoId, patente, marca, modelo, anio, "Sedan", estado);

        int filas = dbHelper.updateVehiculo(v);

        if (filas > 0) {
            Toast.makeText(this, "¡Vehículo Actualizado!", Toast.LENGTH_SHORT).show();
            finish(); // Volver a la lista
        } else {
            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmarEliminacion() {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar Vehículo")
                .setMessage("¿Estás seguro de eliminar el vehículo " + etPatente.getText().toString() + "?")
                .setPositiveButton("Sí, Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper.deleteVehiculo(vehiculoId);
                        Toast.makeText(DetalleVehiculoActivity.this, "Eliminado", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}