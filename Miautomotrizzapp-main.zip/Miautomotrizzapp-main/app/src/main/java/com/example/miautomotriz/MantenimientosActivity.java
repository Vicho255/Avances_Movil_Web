package com.example.miautomotriz;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MantenimientosActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FloatingActionButton fab;
    private VehiculoDbHelper dbHelper;
    private MantenimientoAdapter adapter;

    // Datos automáticos
    private String[] servicios = {
            "Cambio de Aceite", "Revisión de Frenos", "Alineación y Balanceo",
            "Cambio de Batería", "Revisión General", "Cambio de Neumáticos"
    };
    private int[] precios = { 45000, 80000, 35000, 65000, 25000, 120000 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mantenimientos);

        dbHelper = new VehiculoDbHelper(this);

        recyclerView = findViewById(R.id.recyclerMantenimientos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fab = findViewById(R.id.fabAgregarMant);

        cargarLista();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoAgregar();
            }
        });
    }

    private void cargarLista() {
        List<Mantenimiento> lista = dbHelper.getAllMantenimientos();

        // Configuramos el adaptador CON el listener del click
        adapter = new MantenimientoAdapter(lista, new MantenimientoAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Mantenimiento mantenimiento) {
                mostrarDialogoConfirmacion(mantenimiento);
            }
        });

        recyclerView.setAdapter(adapter);
    }

    // --- NUEVO: Diálogo para terminar/eliminar mantenimiento ---
    private void mostrarDialogoConfirmacion(Mantenimiento m) {
        new AlertDialog.Builder(this)
                .setTitle("Gestionar Mantenimiento")
                .setMessage("¿Marcar el servicio de '" + m.getDescripcion() + "' como LISTO y eliminarlo de la lista pendiente?")
                .setPositiveButton("¡Sí, Trabajo Listo!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 1. Borrar de la BD
                        dbHelper.deleteMantenimiento(m.getId());
                        // 2. Actualizar la lista visual
                        cargarLista();
                        // 3. Mensaje de éxito
                        Toast.makeText(MantenimientosActivity.this, "¡Mantenimiento Finalizado!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void mostrarDialogoAgregar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View viewInflated = LayoutInflater.from(this).inflate(R.layout.dialog_mantenimiento, null);
        builder.setView(viewInflated);

        final Spinner spinnerVehiculos = viewInflated.findViewById(R.id.spinnerVehiculos);
        final Spinner spinnerServicios = viewInflated.findViewById(R.id.spinnerServicios);
        final EditText etFecha = viewInflated.findViewById(R.id.etMantFecha);
        final EditText etCosto = viewInflated.findViewById(R.id.etMantCosto);

        // Llenar Spinners
        List<String> patentes = dbHelper.getAllPatentes();
        if (patentes.isEmpty()) {
            Toast.makeText(this, "Primero agrega vehículos", Toast.LENGTH_LONG).show();
            return;
        }
        ArrayAdapter<String> adapterVehiculos = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, patentes);
        spinnerVehiculos.setAdapter(adapterVehiculos);

        ArrayAdapter<String> adapterServicios = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, servicios);
        spinnerServicios.setAdapter(adapterServicios);

        // Fecha automática
        String fechaHoy = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        etFecha.setText(fechaHoy);

        // Precio automático
        spinnerServicios.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                etCosto.setText(String.valueOf(precios[position]));
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        builder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String patente = spinnerVehiculos.getSelectedItem().toString();
                String desc = spinnerServicios.getSelectedItem().toString();
                String fecha = etFecha.getText().toString();
                String costoStr = etCosto.getText().toString();

                if (!costoStr.isEmpty()) {
                    Mantenimiento m = new Mantenimiento(patente, fecha, desc, Integer.parseInt(costoStr));
                    dbHelper.addMantenimiento(m);
                    cargarLista();
                    Toast.makeText(MantenimientosActivity.this, "Agregado", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
}