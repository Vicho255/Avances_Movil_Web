package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MantenimientoAdapter extends RecyclerView.Adapter<MantenimientoAdapter.MantenimientoViewHolder> {

    private List<Mantenimiento> lista;
    private OnItemClickListener listener; // Escuchador de clicks

    // Interfaz para comunicar el click a la actividad
    public interface OnItemClickListener {
        void onItemClick(Mantenimiento mantenimiento);
    }

    // Constructor actualizado (ahora recibe el listener)
    public MantenimientoAdapter(List<Mantenimiento> lista, OnItemClickListener listener) {
        this.lista = lista;
        this.listener = listener;
    }

    public static class MantenimientoViewHolder extends RecyclerView.ViewHolder {
        TextView tvDescripcion, tvPatente, tvCosto, tvFecha;

        public MantenimientoViewHolder(View view) {
            super(view);
            tvDescripcion = view.findViewById(R.id.tvMantDescripcion);
            tvPatente = view.findViewById(R.id.tvMantPatente);
            tvCosto = view.findViewById(R.id.tvMantCosto);
            tvFecha = view.findViewById(R.id.tvMantFecha);
        }
    }

    @NonNull
    @Override
    public MantenimientoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_mantenimiento, parent, false);
        return new MantenimientoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MantenimientoViewHolder holder, int position) {
        Mantenimiento m = lista.get(position);

        holder.tvDescripcion.setText(m.getDescripcion());
        holder.tvPatente.setText("Vehículo: " + m.getPatenteVehiculo());
        holder.tvCosto.setText("$" + m.getCosto());
        holder.tvFecha.setText(m.getFecha());

        // Aquí detectamos el click en la tarjeta completa
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(m); // Avisamos a la actividad
            }
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }
}