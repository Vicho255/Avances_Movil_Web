package com.example.miautomotriz;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MisReparacionesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText etBuscar;
    private FloatingActionButton fabAgendar;
    private ReparacionApiAdapter adapter;

    // CONFIGURACIÓN RETROFIT
    // Si usas EMULADOR: "http://10.0.2.2/api_automotriz/"
    // Si usas CELULAR: "http://192.168.1.X/api_automotriz/" (Pon tu IP real)
    private static final String BASE_URL = "http://10.0.2.2/api_automotriz/";
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_reparaciones);

        // 1. Iniciar Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiService = retrofit.create(ApiService.class);

        // 2. UI
        etBuscar = findViewById(R.id.etBuscarReparacion);
        recyclerView = findViewById(R.id.recyclerReparacionesApi);
        fabAgendar = findViewById(R.id.fabAgendar);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 3. Cargar datos al iniciar
        cargarDatos();

        // 4. Buscador
        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) adapter.filtrar(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        // 5. Botón Agendar
        fabAgendar.setOnClickListener(v -> mostrarDialogoAgendar());
    }

    private void cargarDatos() {
        Call<List<Reparacion>> call = apiService.obtenerReparaciones();

        call.enqueue(new Callback<List<Reparacion>>() {
            @Override
            public void onResponse(Call<List<Reparacion>> call, Response<List<Reparacion>> response) {
                if (response.isSuccessful()) {
                    List<Reparacion> lista = response.body();
                    if (lista == null) lista = new ArrayList<>();

                    // Configurar el adaptador (Pasamos la lista y la función para aprobar)
                    adapter = new ReparacionApiAdapter(lista, id -> aprobarCotizacion(id));
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(MisReparacionesActivity.this, "Error servidor: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Reparacion>> call, Throwable t) {
                Toast.makeText(MisReparacionesActivity.this, "Fallo conexión: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarDialogoAgendar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agendar Cita");

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_agendar_api, null);
        builder.setView(view);

        final EditText etPatente = view.findViewById(R.id.etPatente);
        final EditText etDesc = view.findViewById(R.id.etDesc);
        final EditText etFecha = view.findViewById(R.id.etFecha);
        final EditText etCosto = view.findViewById(R.id.etCosto);

        builder.setPositiveButton("Agendar", (dialog, which) -> {
            String p = etPatente.getText().toString();
            String d = etDesc.getText().toString();
            String f = etFecha.getText().toString();
            String c = etCosto.getText().toString();

            if (!p.isEmpty() && !c.isEmpty()) {
                agendarCitaServidor(p, d, f, c);
            } else {
                Toast.makeText(this, "Faltan datos", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void agendarCitaServidor(String patente, String desc, String fecha, String costo) {
        Call<Void> call = apiService.agendarCita(patente, desc, fecha, costo);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MisReparacionesActivity.this, "¡Cita Agendada!", Toast.LENGTH_SHORT).show();
                    cargarDatos(); // Recargar la lista para ver la nueva cita
                } else {
                    Toast.makeText(MisReparacionesActivity.this, "Error al guardar", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(MisReparacionesActivity.this, "Error red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void aprobarCotizacion(String id) {
        Call<Void> call = apiService.aprobarCotizacion(id);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MisReparacionesActivity.this, "¡Cotización Aprobada!", Toast.LENGTH_SHORT).show();
                    cargarDatos(); // Recargar para ver el cambio de color
                } else {
                    Toast.makeText(MisReparacionesActivity.this, "Error al aprobar", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(MisReparacionesActivity.this, "Error red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}