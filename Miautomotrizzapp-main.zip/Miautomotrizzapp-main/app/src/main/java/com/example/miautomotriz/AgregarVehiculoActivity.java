package com.example.miautomotriz;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

// Importaciones necesarias para Retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AgregarVehiculoActivity extends AppCompatActivity {

    // Vistas del layout
    private TextInputEditText etPatente;
    private TextInputEditText etMarca;
    private TextInputEditText etModelo;
    private TextInputEditText etAnio;
    private AutoCompleteTextView actvTipo;
    private AutoCompleteTextView actvEstado;
    private Button btnGuardarVehiculo;
    private Button btnVolverMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Agregar Vehículo");
        }

        inicializarVistas();
        configurarSpinners();
        configurarListeners();
    }

    private void inicializarVistas() {
        etPatente = findViewById(R.id.etPatente);
        etMarca = findViewById(R.id.etMarca);
        etModelo = findViewById(R.id.etModelo);
        etAnio = findViewById(R.id.etAnio);
        actvTipo = findViewById(R.id.actvTipo);
        actvEstado = findViewById(R.id.actvEstado);
        btnGuardarVehiculo = findViewById(R.id.btnGuardarVehiculo);
        btnVolverMenu = findViewById(R.id.btnVolverMenu);
    }

    private void configurarSpinners() {
        String[] tipos = new String[]{"Sedán", "Hatchback", "Camioneta", "SUV", "Otro"};
        ArrayAdapter<String> adapterTipo = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                tipos
        );
        actvTipo.setAdapter(adapterTipo);

        String[] estados = new String[]{"Disponible", "En Mantenimiento", "Vendido"};
        ArrayAdapter<String> adapterEstado = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                estados
        );
        actvEstado.setAdapter(adapterEstado);
    }

    private void configurarListeners() {
        btnVolverMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnGuardarVehiculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarNuevoVehiculo();
            }
        });
    }

    private void guardarNuevoVehiculo() {
        // 1. Obtener los datos
        String patente = etPatente.getText().toString().trim();
        String marca = etMarca.getText().toString().trim();
        String modelo = etModelo.getText().toString().trim();
        String anioStr = etAnio.getText().toString().trim();
        String tipo = actvTipo.getText().toString();
        String estado = actvEstado.getText().toString();

        // 2. Validar campos vacíos
        if (patente.isEmpty() || marca.isEmpty() || modelo.isEmpty() || anioStr.isEmpty() || tipo.isEmpty() || estado.isEmpty()) {
            Toast.makeText(this, "Debe completar todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // 3. Convertir año
        int anio;
        try {
            anio = Integer.parseInt(anioStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "El año no es un número válido", Toast.LENGTH_SHORT).show();
            return;
        }

        // 4. Crear el objeto Vehiculo
        Vehiculo nuevoVehiculo = new Vehiculo(patente, marca, modelo, anio, tipo, estado);

        // 5. ENVIAR A XAMPP (Retrofit)

        // NOTA: "http://10.0.2.2/..." es la IP especial para el Emulador de Android.
        // Si usas celular físico, cambia esto por tu IP de PC (ej: "http://192.168.1.15/api_automotriz/")
        String url = "http://10.0.2.2/api_automotriz/";

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService service = retrofit.create(ApiService.class);
        Call<Void> llamada = service.registrarVehiculo(nuevoVehiculo);

        llamada.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AgregarVehiculoActivity.this, "¡Guardado en XAMPP!", Toast.LENGTH_SHORT).show();
                    finish(); // Cierra la pantalla y vuelve al menú
                } else {
                    Toast.makeText(AgregarVehiculoActivity.this, "Error del servidor: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(AgregarVehiculoActivity.this, "Fallo conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}