<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patente = $_POST['patente'];
    $descripcion = $_POST['descripcion'];
    $fecha = $_POST['fecha'];
    $costo = $_POST['costo'];
    
    // Por defecto el estado será 'Pendiente'
    $estado = 'Pendiente';

    $sql = "INSERT INTO reparaciones (patente, descripcion, fecha, costo, estado) VALUES ('$patente', '$descripcion', '$fecha', '$costo', '$estado')";

    if (mysqli_query($conexion, $sql)) {
        echo "Cita Agendada";
    } else {
        echo "Error";
    }
}
mysqli_close($conexion);
?>