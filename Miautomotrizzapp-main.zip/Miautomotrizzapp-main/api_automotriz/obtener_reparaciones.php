<?php
include 'conexion.php';

// Consultamos todas las reparaciones
$consulta = "SELECT * FROM reparaciones";
$resultado = mysqli_query($conexion, $consulta);

$reparaciones = array();

while ($fila = mysqli_fetch_assoc($resultado)) {
    $reparaciones[] = $fila;
}

// Convertimos los datos a JSON (el idioma que entiende Android)
echo json_encode($reparaciones);
mysqli_close($conexion);
?>