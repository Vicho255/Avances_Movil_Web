<?php
$hostname = "localhost";
$database = "taller_automotriz";
$username = "root";
$password = "";

$conexion = mysqli_connect($hostname, $username, $password, $database);

if (!$conexion) {
    echo "Error de conexion";
}
?>