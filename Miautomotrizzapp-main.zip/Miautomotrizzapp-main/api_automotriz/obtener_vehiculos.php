<?php
include 'conexion.php';

// Consulta para traer todos los vehículos
$sql = "SELECT * FROM vehiculos";
$result = $conexion->query($sql);

$vehiculos = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $vehiculos[] = $row;
    }
}

// Devolver en formato JSON (que Android entiende)
echo json_encode($vehiculos);
?>