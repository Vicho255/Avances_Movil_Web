<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_reparacion = $_POST['id_reparacion'];

    // Actualizamos el estado a 'Aprobado'
    $consulta = "UPDATE reparaciones SET estado = 'Aprobado' WHERE id = '$id_reparacion'";

    if (mysqli_query($conexion, $consulta)) {
        echo "Actualizado correctamente";
    } else {
        echo "Error al actualizar";
    }
}
mysqli_close($conexion);
?>