<?php
include 'conexion.php';

// Recibimos los datos enviados por la App
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Buscamos en la base de datos
    $consulta = "SELECT * FROM usuarios WHERE username = '$username' AND password = '$password'";
    $resultado = mysqli_query($conexion, $consulta);

    if (mysqli_num_rows($resultado) > 0) {
        // Si encontró al usuario, devolvemos éxito y el rol
        $fila = mysqli_fetch_assoc($resultado);
        echo json_encode(array(
            "status" => "success",
            "mensaje" => "Bienvenido",
            "rol" => $fila['rol']
        ));
    } else {
        echo json_encode(array("status" => "error", "mensaje" => "Usuario o clave incorrectos"));
    }
}
mysqli_close($conexion);
?>