<?php
include 'conexion.php';

// Verificamos si reciben datos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patente = $_POST['patente'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $anio = $_POST['anio'];
    $estado = 'Disponible'; // Por defecto

    $query = "INSERT INTO vehiculos (patente, marca, modelo, anio, estado) VALUES ('$patente', '$marca', '$modelo', '$anio', '$estado')";

    if (mysqli_query($conexion, $query)) {
        // Si vienes de la web, redirigimos de vuelta
        if(isset($_POST['origen']) && $_POST['origen'] == 'web'){
            header("Location: ../taller_web/vehiculos.php");
        } else {
            echo "Vehículo Agregado";
        }
    } else {
        echo "Error: " . mysqli_error($conexion);
    }
}
mysqli_close($conexion);
?>