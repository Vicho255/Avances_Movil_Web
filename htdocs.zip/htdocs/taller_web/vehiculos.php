<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Vehículos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container">
        <span class="navbar-brand h1">🚗 Taller Automotriz - Vehículos</span>
        <a href="dashboard.php" class="btn btn-light btn-sm">Volver al Dashboard</a>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header bg-success text-white">Nuevo Vehículo</div>
                <div class="card-body">
                    <form action="../api_automotriz/guardar_vehiculo.php" method="POST">
                        <input type="hidden" name="origen" value="web">
                        
                        <div class="mb-3">
                            <label>Patente</label>
                            <input type="text" name="patente" class="form-control" required placeholder="Ej: ABCD-10">
                        </div>
                        <div class="mb-3">
                            <label>Marca</label>
                            <input type="text" name="marca" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Modelo</label>
                            <input type="text" name="modelo" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Año</label>
                            <input type="number" name="anio" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Guardar Vehículo</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header">Flota Actual</div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patente</th>
                                <th>Marca</th>
                                <th>Modelo</th>
                                <th>Año</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'conexion.php';
                            $resultado = mysqli_query($conexion, "SELECT * FROM vehiculos");
                            while ($fila = mysqli_fetch_assoc($resultado)) {
                                echo "<tr>";
                                echo "<td>" . $fila['patente'] . "</td>";
                                echo "<td>" . $fila['marca'] . "</td>";
                                echo "<td>" . $fila['modelo'] . "</td>";
                                echo "<td>" . $fila['anio'] . "</td>";
                                
                                $color = ($fila['estado'] == 'Disponible') ? 'badge bg-primary' : 'badge bg-danger';
                                echo "<td><span class='$color'>" . $fila['estado'] . "</span></td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>