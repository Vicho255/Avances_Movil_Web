package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ReparacionApiAdapter extends RecyclerView.Adapter<ReparacionApiAdapter.ViewHolder> {

    private List<Reparacion> listaOriginal; // Lista completa
    private List<Reparacion> listaFiltrada; // Lista que se muestra al buscar
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onAprobarClick(String id);
    }

    public ReparacionApiAdapter(List<Reparacion> lista, OnItemClickListener listener) {
        this.listaOriginal = lista;
        this.listaFiltrada = new ArrayList<>(lista);
        this.listener = listener;
    }

    // --- LÓGICA DEL FILTRO (BUSCADOR) ---
    public void filtrar(String texto) {
        listaFiltrada.clear();
        if (texto.isEmpty()) {
            listaFiltrada.addAll(listaOriginal);
        } else {
            for (Reparacion r : listaOriginal) {
                // Filtramos por PATENTE
                if (r.getPatente().toLowerCase().contains(texto.toLowerCase())) {
                    listaFiltrada.add(r);
                }
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reparacion_api, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Reparacion r = listaFiltrada.get(position);
        holder.tvPatente.setText(r.getPatente());
        holder.tvDesc.setText(r.getDescripcion());
        holder.tvCosto.setText("$" + r.getCosto());
        holder.tvEstado.setText(r.getEstado());

        // Si ya está aprobado, bloqueamos el botón
        if (r.getEstado().equalsIgnoreCase("Aprobado")) {
            holder.btnAprobar.setEnabled(false);
            holder.btnAprobar.setText("Aprobado");
        } else {
            holder.btnAprobar.setEnabled(true);
            holder.btnAprobar.setText("Aprobar Cotización");
            // Al hacer clic, avisamos a la actividad para hacer el POST
            holder.btnAprobar.setOnClickListener(v -> listener.onAprobarClick(r.getId()));
        }
    }

    @Override
    public int getItemCount() { return listaFiltrada.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatente, tvDesc, tvCosto, tvEstado;
        Button btnAprobar;

        public ViewHolder(View view) {
            super(view);
            tvPatente = view.findViewById(R.id.tvPatenteApi);
            tvDesc = view.findViewById(R.id.tvDescApi);
            tvCosto = view.findViewById(R.id.tvCostoApi);
            tvEstado = view.findViewById(R.id.tvEstadoApi);
            btnAprobar = view.findViewById(R.id.btnAprobarApi);
        }
    }
}