package com.example.miautomotriz;

public class Reparacion {
    private String id;
    private String patente;
    private String descripcion;
    private String costo;
    private String estado;

    public Reparacion(String id, String patente, String descripcion, String costo, String estado) {
        this.id = id;
        this.patente = patente;
        this.descripcion = descripcion;
        this.costo = costo;
        this.estado = estado;
    }

    public String getId() { return id; }
    public String getPatente() { return patente; }
    public String getDescripcion() { return descripcion; }
    public String getCosto() { return costo; }
    public String getEstado() { return estado; }
}