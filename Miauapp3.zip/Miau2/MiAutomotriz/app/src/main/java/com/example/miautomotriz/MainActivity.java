package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VehiculoAdapter adapter;
    private VehiculoDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inicializar Base de Datos
        dbHelper = new VehiculoDbHelper(this);

        // 2. Configurar RecyclerView
        recyclerView = findViewById(R.id.recyclerViewVehiculos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 3. Configurar Botón para ir a Agregar
        FloatingActionButton fab = findViewById(R.id.fabAgregar);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar a la pantalla de agregar
                Intent intent = new Intent(MainActivity.this, AgregarVehiculoActivity.class);
                startActivity(intent);
            }
        });
    }

    // Usamos onResume para recargar la lista cada vez que volvemos a esta pantalla
    @Override
    protected void onResume() {
        super.onResume();
        cargarListaVehiculos();
    }

    private void cargarListaVehiculos() {
        // Obtener lista actualizada de la BD
        List<Vehiculo> lista = dbHelper.getAllVehiculos();

        // Configurar el adaptador
        adapter = new VehiculoAdapter(lista);
        recyclerView.setAdapter(adapter);
    }
}