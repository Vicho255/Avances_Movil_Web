package com.example.miautomotriz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private LinearLayout btnVehiculos, btnMantenimientos, btnVentas, btnReportes, btnConfiguracion;
    private Button btnCerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        inicializarVistas();
        configurarListeners();
    }

    private void inicializarVistas() {
        btnVehiculos = findViewById(R.id.btnVehiculos);
        btnMantenimientos = findViewById(R.id.btnMantenimientos);
        btnVentas = findViewById(R.id.btnVentas);
        btnReportes = findViewById(R.id.btnReportes);
        btnConfiguracion = findViewById(R.id.btnConfiguracion);
        btnCerrar = findViewById(R.id.btnCerrar);
    }

    private void configurarListeners() {
        // --- BOTÓN IR A VEHÍCULOS (Gestión Local) ---
        btnVehiculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // --- BOTÓN MANTENIMIENTOS / REPARACIONES (CONECTADO A LA API) ---
        btnMantenimientos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abre la pantalla nueva que usa Volley y XAMPP
                Intent intent = new Intent(MenuActivity.this, MisReparacionesActivity.class);
                startActivity(intent);
            }
        });

        // --- BOTÓN VENTAS ---
        btnVentas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, VentasActivity.class);
                startActivity(intent);
            }
        });

        // --- BOTÓN REPORTES ---
        btnReportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, ReportesActivity.class);
                startActivity(intent);
            }
        });

        // --- BOTÓN CONFIGURACIÓN ---
        btnConfiguracion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, ConfiguracionActivity.class);
                startActivity(intent);
            }
        });

        // --- BOTÓN CERRAR (Solo minimiza la app) ---
        btnCerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // =========================================================
    //        MENÚ DE OPCIONES (CERRAR SESIÓN REAL)
    // =========================================================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {

            // 1. Borrar la sesión de la memoria
            SharedPreferences preferences = getSharedPreferences("sesion_usuario", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("estado_sesion", false);
            editor.clear(); // Borra todo
            editor.apply();

            // 2. Volver al Login y limpiar historial para no poder volver atrás
            Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}