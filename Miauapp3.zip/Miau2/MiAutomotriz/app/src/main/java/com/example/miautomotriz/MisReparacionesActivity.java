package com.example.miautomotriz;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MisReparacionesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText etBuscar;
    private FloatingActionButton fabAgendar;
    private ReparacionApiAdapter adapter;
    private List<Reparacion> listaReparaciones;

    // --- IMPORTANTE: Revisa que esta sea TU IP actual (cmd -> ipconfig) ---
    private static final String IP = "192.168.1.9";
    private static final String URL_GET = "http://" + IP + "/api_automotriz/obtener_reparaciones.php";
    private static final String URL_APROBAR = "http://" + IP + "/api_automotriz/aprobar_cotizacion.php";
    private static final String URL_AGENDAR = "http://" + IP + "/api_automotriz/agendar_cita.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_reparaciones);

        etBuscar = findViewById(R.id.etBuscarReparacion);
        recyclerView = findViewById(R.id.recyclerReparacionesApi);
        fabAgendar = findViewById(R.id.fabAgendar);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listaReparaciones = new ArrayList<>();

        cargarDatos();

        // 1. FILTRO
        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) adapter.filtrar(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        // 2. BOTÓN AGENDAR
        fabAgendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoAgendar(); // Llamamos al método que está MÁS ABAJO
            }
        });
    }

    // --- AQUÍ ESTÁ EL MÉTODO (Dentro de la clase, no en otro archivo) ---
    private void mostrarDialogoAgendar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Agendar Cita (Servidor)");

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_agendar_api, null);
        builder.setView(view);

        final EditText etPatente = view.findViewById(R.id.etPatente);
        final EditText etDesc = view.findViewById(R.id.etDesc);
        final EditText etFecha = view.findViewById(R.id.etFecha);
        final EditText etCosto = view.findViewById(R.id.etCosto);

        builder.setPositiveButton("Agendar", (dialog, which) -> {
            String p = etPatente.getText().toString();
            String d = etDesc.getText().toString();
            String f = etFecha.getText().toString();
            String c = etCosto.getText().toString();

            if(!p.isEmpty() && !c.isEmpty()) {
                agendarCitaServidor(p, d, f, c);
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void agendarCitaServidor(String patente, String desc, String fecha, String costo) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL_AGENDAR,
                response -> {
                    Toast.makeText(this, "Cita Agendada", Toast.LENGTH_SHORT).show();
                    cargarDatos();
                },
                error -> Toast.makeText(this, "Error al agendar", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patente", patente);
                params.put("descripcion", desc);
                params.put("fecha", fecha);
                params.put("costo", costo);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(postRequest);
    }

    private void cargarDatos() {
        StringRequest request = new StringRequest(Request.Method.GET, URL_GET,
                response -> {
                    try {
                        listaReparaciones.clear();
                        JSONArray jsonArray = new JSONArray(response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject o = jsonArray.getJSONObject(i);
                            listaReparaciones.add(new Reparacion(
                                    o.getString("id"),
                                    o.getString("patente"),
                                    o.getString("descripcion"),
                                    o.getString("costo"),
                                    o.getString("estado")
                            ));
                        }
                        adapter = new ReparacionApiAdapter(listaReparaciones, id -> aprobarCotizacion(id));
                        recyclerView.setAdapter(adapter);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(request);
    }

    private void aprobarCotizacion(final String id) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL_APROBAR,
                response -> {
                    Toast.makeText(this, "Cotización Aprobada", Toast.LENGTH_SHORT).show();
                    cargarDatos();
                },
                error -> Toast.makeText(this, "Error al aprobar", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id_reparacion", id);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(postRequest);
    }
}