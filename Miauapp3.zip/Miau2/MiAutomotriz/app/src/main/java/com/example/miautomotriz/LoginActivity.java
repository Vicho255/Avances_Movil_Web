package com.example.miautomotriz;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// Librerías de Volley y JSON
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilUsuario, tilPassword;
    private TextInputEditText etUsuario, etPassword;
    private Button btnLogin;

    // DIRECCIÓN DE TU SERVIDOR (OJO AQUÍ)
    // Usa 10.0.2.2 si estás en el emulador.
    // Usa tu IP local (ej. 192.168.x.x) si usas celular físico.
    private static final String URL_LOGIN = "http://192.168.1.9/api_automotriz/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. VERIFICAR SESIÓN GUARDADA (SharedPreferences)
        // Si ya te logueaste antes, te manda directo al menú sin pedir clave
        SharedPreferences preferences = getSharedPreferences("sesion_usuario", Context.MODE_PRIVATE);
        boolean sesionActiva = preferences.getBoolean("estado_sesion", false);
        if (sesionActiva) {
            irAlMenu();
        }

        // Vincular vistas
        tilUsuario = findViewById(R.id.tilUsuario);
        tilPassword = findViewById(R.id.tilPassword);
        etUsuario = findViewById(R.id.etUsuario);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarLoginConServidor();
            }
        });
    }

    private void validarLoginConServidor() {
        String usuario = etUsuario.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validaciones básicas visuales
        if (usuario.isEmpty()) {
            tilUsuario.setError("Ingresa usuario");
            return;
        }
        if (password.isEmpty()) {
            tilPassword.setError("Ingresa contraseña");
            return;
        }

        // --- INICIO DE PETICIÓN VOLLEY ---
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Convertimos la respuesta del servidor (Texto) a un objeto JSON
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");

                            if (status.equals("success")) {
                                // LOGIN EXITOSO
                                String rol = jsonObject.getString("rol");
                                String msj = jsonObject.getString("mensaje");

                                Toast.makeText(LoginActivity.this, msj, Toast.LENGTH_SHORT).show();

                                // 2. GUARDAR SESIÓN (Requisito del Avance)
                                guardarSesion(usuario, rol);

                                irAlMenu();
                            } else {
                                // LOGIN FALLIDO (Usuario o clave mal)
                                String errorMsj = jsonObject.getString("mensaje");
                                tilPassword.setError(errorMsj);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(LoginActivity.this, "Error en los datos del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Error de conexión (Servidor apagado o IP incorrecta)
                        Toast.makeText(LoginActivity.this, "No se pudo conectar al servidor. Revisa la IP o XAMPP.", Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                // AQUÍ ENVIAMOS LOS DATOS AL PHP
                Map<String, String> params = new HashMap<>();
                params.put("username", usuario);
                params.put("password", password);
                return params;
            }
        };

        // Añadimos la petición a la cola para que se ejecute
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void guardarSesion(String usuario, String rol) {
        SharedPreferences preferences = getSharedPreferences("sesion_usuario", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("estado_sesion", true);
        editor.putString("usuario", usuario);
        editor.putString("rol", rol);
        editor.apply(); // Guardar cambios
    }

    private void irAlMenu() {
        Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
        startActivity(intent);
        finish(); // Cierra el login para no volver atrás
    }
}