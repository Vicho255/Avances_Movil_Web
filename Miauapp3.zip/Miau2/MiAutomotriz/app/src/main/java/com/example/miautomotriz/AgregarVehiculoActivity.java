package com.example.miautomotriz;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class AgregarVehiculoActivity extends AppCompatActivity {

    // Vistas del layout
    private TextInputEditText etPatente;
    private TextInputEditText etMarca;
    private TextInputEditText etModelo;
    private TextInputEditText etAnio;
    private AutoCompleteTextView actvTipo; // <-- CAMBIO: Ya no es Spinner
    private AutoCompleteTextView actvEstado; // <-- CAMBIO: Ya no es Spinner
    private Button btnGuardarVehiculo;
    private Button btnVolverMenu;

    // Helper de la Base de Datos
    private VehiculoDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);

        // Cambiar el título de la barra de acción
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Agregar Vehículo");
        }

        // Inicializar el helper de la DB
        dbHelper = new VehiculoDbHelper(this);

        // Vincular vistas
        inicializarVistas();

        // Configurar los menús desplegables (Spinners modernos)
        configurarSpinners();

        // Configurar los botones
        configurarListeners();
    }

    private void inicializarVistas() {
        // Campos de texto
        etPatente = findViewById(R.id.etPatente);
        etMarca = findViewById(R.id.etMarca);
        etModelo = findViewById(R.id.etModelo);
        etAnio = findViewById(R.id.etAnio);

        // Menús desplegables (AutoCompleteTextView)
        actvTipo = findViewById(R.id.actvTipo);
        actvEstado = findViewById(R.id.actvEstado);

        // Botones
        btnGuardarVehiculo = findViewById(R.id.btnGuardarVehiculo);
        btnVolverMenu = findViewById(R.id.btnVolverMenu);
    }

    private void configurarSpinners() {
        // --- Configurar Spinner de TIPO ---
        // 1. Crear la lista de opciones
        String[] tipos = new String[]{"Sedán", "Hatchback", "Camioneta", "SUV", "Otro"};
        // 2. Crear un ArrayAdapter
        ArrayAdapter<String> adapterTipo = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line, // Layout simple para el ítem
                tipos
        );
        // 3. Asignar el adaptador al AutoCompleteTextView
        actvTipo.setAdapter(adapterTipo);

        // --- Configurar Spinner de ESTADO ---
        String[] estados = new String[]{"Disponible", "En Mantenimiento", "Vendido"};
        ArrayAdapter<String> adapterEstado = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                estados
        );
        actvEstado.setAdapter(adapterEstado);
    }

    private void configurarListeners() {
        btnVolverMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra la actividad actual y vuelve a la anterior
            }
        });

        btnGuardarVehiculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarNuevoVehiculo();
            }
        });
    }

    private void guardarNuevoVehiculo() {
        // 1. Obtener los datos de las vistas
        String patente = etPatente.getText().toString().trim();
        String marca = etMarca.getText().toString().trim();
        String modelo = etModelo.getText().toString().trim();
        String anioStr = etAnio.getText().toString().trim();
        String tipo = actvTipo.getText().toString(); // <-- CAMBIO: Así se obtiene el texto
        String estado = actvEstado.getText().toString(); // <-- CAMBIO: Así se obtiene el texto

        // 2. Validar que los campos no estén vacíos
        if (patente.isEmpty() || marca.isEmpty() || modelo.isEmpty() || anioStr.isEmpty() || tipo.isEmpty() || estado.isEmpty()) {
            Toast.makeText(this, "Debe completar todos los campos", Toast.LENGTH_SHORT).show();
            return; // No continuar si faltan datos
        }

        // 3. Convertir el año a número (con control de errores)
        int anio;
        try {
            anio = Integer.parseInt(anioStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "El año no es un número válido", Toast.LENGTH_SHORT).show();
            return;
        }

        // 4. Crear el objeto Vehiculo
        Vehiculo nuevoVehiculo = new Vehiculo(patente, marca, modelo, anio, tipo, estado);

        // 5. Guardar en la base de datos
        try {
            dbHelper.addVehiculo(nuevoVehiculo);
            Toast.makeText(this, "Vehículo guardado correctamente", Toast.LENGTH_SHORT).show();
            finish(); // Cierra la actividad y vuelve al MainActivity (que se refrescará)
        } catch (Exception e) {
            // Esto suele pasar si la patente (UNIQUE) ya existe
            Toast.makeText(this, "Error al guardar: Patente duplicada", Toast.LENGTH_LONG).show();
        }
    }
}