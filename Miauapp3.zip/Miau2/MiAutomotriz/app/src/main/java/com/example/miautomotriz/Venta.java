package com.example.miautomotriz;

public class Venta {
    private int id;
    private String patenteVehiculo;
    private String cliente;
    private String fecha;
    private int monto;

    public Venta() { }

    public Venta(String patenteVehiculo, String cliente, String fecha, int monto) {
        this.patenteVehiculo = patenteVehiculo;
        this.cliente = cliente;
        this.fecha = fecha;
        this.monto = monto;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPatenteVehiculo() { return patenteVehiculo; }
    public void setPatenteVehiculo(String patenteVehiculo) { this.patenteVehiculo = patenteVehiculo; }

    public String getCliente() { return cliente; }
    public void setCliente(String cliente) { this.cliente = cliente; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public int getMonto() { return monto; }
    public void setMonto(int monto) { this.monto = monto; }
}