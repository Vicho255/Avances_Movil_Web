package com.example.miautomotriz;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VentasActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FloatingActionButton fab;
    private VehiculoDbHelper dbHelper;
    private VentaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);

        dbHelper = new VehiculoDbHelper(this);

        // Configurar lista
        recyclerView = findViewById(R.id.recyclerVentas);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Configurar botón
        fab = findViewById(R.id.fabAgregarVenta);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoNuevaVenta();
            }
        });

        cargarLista();
    }

    private void cargarLista() {
        List<Venta> lista = dbHelper.getAllVentas();
        adapter = new VentaAdapter(lista);
        recyclerView.setAdapter(adapter);
    }

    private void mostrarDialogoNuevaVenta() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Inflamos el diseño dialog_venta.xml que creamos
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_venta, null);
        builder.setView(view);

        final Spinner spinnerAutos = view.findViewById(R.id.spinnerAutosDisponibles);
        final EditText etCliente = view.findViewById(R.id.etCliente);
        final EditText etMonto = view.findViewById(R.id.etMontoVenta);
        final EditText etFecha = view.findViewById(R.id.etFechaVenta);

        // 1. LLENAR SPINNER SOLO CON AUTOS DISPONIBLES
        List<String> autosDisponibles = dbHelper.getVehiculosDisponibles();

        if (autosDisponibles.isEmpty()) {
            Toast.makeText(this, "No hay vehículos disponibles para vender", Toast.LENGTH_LONG).show();
            return; // Detenemos aquí si no hay autos
        }

        ArrayAdapter<String> adapterSpin = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, autosDisponibles);
        spinnerAutos.setAdapter(adapterSpin);

        // 2. FECHA AUTOMÁTICA
        String hoy = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        etFecha.setText(hoy);

        builder.setPositiveButton("Vender", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String patente = spinnerAutos.getSelectedItem().toString();
                String cliente = etCliente.getText().toString();
                String montoStr = etMonto.getText().toString();
                String fecha = etFecha.getText().toString();

                if (!cliente.isEmpty() && !montoStr.isEmpty()) {
                    Venta venta = new Venta(patente, cliente, fecha, Integer.parseInt(montoStr));

                    // ESTA LÍNEA ES MÁGICA: Registra venta y cambia estado a "Vendido"
                    dbHelper.registrarVenta(venta);

                    cargarLista();
                    Toast.makeText(VentasActivity.this, "¡Vehículo Vendido!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
}