package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class VehiculoAdapter extends RecyclerView.Adapter<VehiculoAdapter.VehiculoViewHolder> {

    private List<Vehiculo> listaVehiculos;

    // Constructor
    public VehiculoAdapter(List<Vehiculo> listaVehiculos) {
        this.listaVehiculos = listaVehiculos;
    }

    // ViewHolder: Referencias a las vistas de CADA ítem
    public static class VehiculoViewHolder extends RecyclerView.ViewHolder {
        TextView tvMarcaModelo, tvPatente, tvEstado;

        public VehiculoViewHolder(View view) {
            super(view);
            // Asegúrate de tener estos IDs en tu layout 'item_vehiculo.xml'
            tvMarcaModelo = view.findViewById(R.id.tvMarcaModelo);
            tvPatente = view.findViewById(R.id.tvPatente);
            tvEstado = view.findViewById(R.id.tvEstado);
        }
    }

    @NonNull
    @Override
    public VehiculoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos el diseño de la fila (item_vehiculo.xml)
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_vehiculo, parent, false);
        return new VehiculoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VehiculoViewHolder holder, int position) {
        Vehiculo vehiculo = listaVehiculos.get(position);

        // 1. Mostrar datos en la fila
        holder.tvMarcaModelo.setText(vehiculo.getMarca() + " " + vehiculo.getModelo() + " (" + vehiculo.getAnio() + ")");
        holder.tvPatente.setText(vehiculo.getPatente());
        holder.tvEstado.setText(vehiculo.getEstado());

        // 2. Programar el Click en la fila completa
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Preparamos el viaje a la pantalla de Detalle
                android.content.Context context = view.getContext();
                android.content.Intent intent = new android.content.Intent(context, DetalleVehiculoActivity.class);

                // Empacamos TODOS los datos del auto para enviarlos
                intent.putExtra("id", vehiculo.getId());
                intent.putExtra("patente", vehiculo.getPatente());
                intent.putExtra("marca", vehiculo.getMarca());
                intent.putExtra("modelo", vehiculo.getModelo());
                intent.putExtra("anio", vehiculo.getAnio());
                intent.putExtra("tipo", vehiculo.getTipo());
                intent.putExtra("estado", vehiculo.getEstado());

                // Iniciamos la actividad
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaVehiculos.size();
    }
}