package com.example.miautomotriz;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class VehiculoAdapter extends RecyclerView.Adapter<VehiculoAdapter.VehiculoViewHolder> {

    private Context context;
    private List<Vehiculo> listaVehiculos;

    public VehiculoAdapter(Context context, List<Vehiculo> listaVehiculos) {
        this.context = context;
        this.listaVehiculos = listaVehiculos;
    }

    @NonNull
    @Override
    public VehiculoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_vehiculo, parent, false);
        return new VehiculoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VehiculoViewHolder holder, int position) {
        Vehiculo vehiculo = listaVehiculos.get(position);

        holder.tvPatente.setText(vehiculo.getPatente());
        holder.tvMarcaModelo.setText(vehiculo.getMarca() + " " + vehiculo.getModelo());
        holder.tvAnio.setText("Año: " + vehiculo.getAnio());
        holder.tvTipo.setText("Tipo: " + vehiculo.getTipo());
        holder.tvEstado.setText(vehiculo.getEstado());

        if (vehiculo.getEstado().equals("Disponible")) {
            holder.tvEstado.setTextColor(context.getResources().getColor(R.color.disponible));
        } else if (vehiculo.getEstado().equals("En Mantenimiento")) {
            holder.tvEstado.setTextColor(context.getResources().getColor(R.color.mantenimiento));
        } else {
            holder.tvEstado.setTextColor(context.getResources().getColor(R.color.vendido));
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetalleVehiculoActivity.class);
                intent.putExtra("vehiculo", vehiculo);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaVehiculos.size();
    }

    public static class VehiculoViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvPatente, tvMarcaModelo, tvAnio, tvTipo, tvEstado;

        public VehiculoViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardViewVehiculo);
            tvPatente = itemView.findViewById(R.id.tvPatente);
            tvMarcaModelo = itemView.findViewById(R.id.tvMarcaModelo);
            tvAnio = itemView.findViewById(R.id.tvAnio);
            tvTipo = itemView.findViewById(R.id.tvTipo);
            tvEstado = itemView.findViewById(R.id.tvEstado);
        }
    }
}
