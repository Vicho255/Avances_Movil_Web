package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View; // Importar View para los listeners
import android.widget.Button; // Importar Button
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DetalleVehiculoActivity extends AppCompatActivity {

    // Vistas para mostrar los detalles
    private TextView tvPatente;
    private TextView tvMarca;
    private TextView tvModelo;
    private TextView tvAnio;
    private TextView tvTipo;
    private TextView tvEstado;

    // --- NUEVO: Vistas para los botones ---
    private Button btnEliminar;
    private Button btnVolver;

    // --- NUEVO: Helper de DB y patente ---
    private VehiculoDbHelper dbHelper;
    private String patenteActual; // Para saber qué vehículo eliminar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_vehiculo);

        // Cambiar el título de la barra de acción
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Detalle del Vehículo");
            // Opcional: Añadir flecha de "atrás"
            // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 1. Inicializar el DB Helper
        dbHelper = new VehiculoDbHelper(this);

        // 2. Inicializar las vistas del layout (incluyendo botones)
        inicializarVistas();

        // 3. Obtener el objeto Vehiculo
        Intent intent = getIntent();
        Vehiculo vehiculo = (Vehiculo) intent.getSerializableExtra("vehiculo");

        // 4. Rellenar los datos si el vehículo existe
        if (vehiculo != null) {
            rellenarDatos(vehiculo);
            // Guardamos la patente por si el usuario decide eliminar
            patenteActual = vehiculo.getPatente();
        } else {
            Toast.makeText(this, "Error al cargar los datos del vehículo", Toast.LENGTH_SHORT).show();
            finish();
            return; // Salir del método si no hay datos
        }

        // 5. --- NUEVO: Configurar los listeners de los botones ---
        configurarListeners();
    }

    /**
     * Vincula las variables de la clase con las vistas del archivo de layout.
     */
    private void inicializarVistas() {
        tvPatente = findViewById(R.id.tv_detalle_patente);
        tvMarca = findViewById(R.id.tv_detalle_marca);
        tvModelo = findViewById(R.id.tv_detalle_modelo);
        tvAnio = findViewById(R.id.tv_detalle_anio);
        tvTipo = findViewById(R.id.tv_detalle_tipo);
        tvEstado = findViewById(R.id.tv_detalle_estado);

        // --- NUEVO: Vincular los botones ---
        btnEliminar = findViewById(R.id.btn_eliminar_vehiculo);
        btnVolver = findViewById(R.id.btn_volver);
    }

    /**
     * Rellena los TextViews con la información del objeto Vehiculo.
     */
    private void rellenarDatos(Vehiculo vehiculo) {
        tvPatente.setText(vehiculo.getPatente());
        tvMarca.setText(vehiculo.getMarca());
        tvModelo.setText(vehiculo.getModelo());
        tvAnio.setText(String.valueOf(vehiculo.getAnio())); // Convertir int a String
        tvTipo.setText(vehiculo.getTipo());
        tvEstado.setText(vehiculo.getEstado());
    }

    /**
     * --- NUEVO: Asigna las acciones a los botones ---
     */
    private void configurarListeners() {
        // Acción para el botón Volver
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cierra esta actividad y regresa a la anterior (MainActivity)
                finish();
            }
        });

        // Acción para el botón Eliminar
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Usar el método deleteVehiculo del DbHelper
                dbHelper.deleteVehiculo(patenteActual);

                // Mostrar confirmación y cerrar la actividad
                Toast.makeText(DetalleVehiculoActivity.this, "Vehículo eliminado", Toast.LENGTH_SHORT).show();
                finish(); // Regresa a MainActivity, que se refrescará en onResume
            }
        });
    }

    // Opcional: Para que la flecha "atrás" de la barra de acción funcione
    /*
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed(); // Simula el botón "atrás" del dispositivo
        return true;
    }
    */
}