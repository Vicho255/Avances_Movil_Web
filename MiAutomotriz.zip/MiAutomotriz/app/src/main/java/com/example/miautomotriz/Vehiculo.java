package com.example.miautomotriz;

import java.io.Serializable;

// Es crucial que implemente Serializable para poder pasar el objeto entre Activities.
public class Vehiculo implements Serializable {

    // --- Campos/Atributos de la clase ---
    // Usamos "patente" para que coincida con lo que buscas en DetalleVehiculoActivity
    private String patente;
    private String marca;
    private String modelo;
    private int anio;
    private String tipo;
    private String estado;

    // --- Constructor ---
    // Permite crear un objeto Vehiculo con todos sus datos de una sola vez.
    public Vehiculo(String patente, String marca, String modelo, int anio, String tipo, String estado) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.tipo = tipo;
        this.estado = estado;
    }

    // --- Métodos "Getter" ---
    // Estos son los métodos que tu Activity necesita para LEER los datos del objeto.

    public String getPatente() {
        return patente;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAnio() {
        return anio;
    }

    public String getTipo() {
        return tipo;
    }

    public String getEstado() {
        return estado;
    }
}
