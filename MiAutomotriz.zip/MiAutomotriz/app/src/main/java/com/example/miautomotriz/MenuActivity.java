package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private LinearLayout btnVehiculos, btnMantenimientos, btnVentas, btnReportes, btnConfiguracion;
    private Button btnCerrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        inicializarVistas();
        configurarListeners();
    }

    private void inicializarVistas() {
        btnVehiculos = findViewById(R.id.btnVehiculos);
        btnMantenimientos = findViewById(R.id.btnMantenimientos);
        btnVentas = findViewById(R.id.btnVentas);
        btnReportes = findViewById(R.id.btnReportes);
        btnConfiguracion = findViewById(R.id.btnConfiguracion);
        btnCerrar = findViewById(R.id.btnCerrar);
    }

    private void configurarListeners() {
        btnVehiculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnMantenimientos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, MantenimientosActivity.class);
                startActivity(intent);
            }
        });

        btnVentas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, VentasActivity.class);
                startActivity(intent);
            }
        });

        btnReportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, ReportesActivity.class);
                startActivity(intent);
            }
        });

        btnConfiguracion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, ConfiguracionActivity.class);
                startActivity(intent);
            }
        });

        btnCerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
