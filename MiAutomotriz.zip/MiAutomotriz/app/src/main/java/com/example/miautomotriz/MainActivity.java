package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

/**
 * Actividad principal que muestra la lista de vehículos en un RecyclerView.
 * Utiliza VehiculoDbHelper para cargar y persistir los datos.
 */
public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VehiculoAdapter adapter;
    private List<Vehiculo> listaVehiculos;
    private FloatingActionButton fabAgregar;
    private Button btnMenuDrawer;

    // Instancia del ayudante de la base de datos
    private VehiculoDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inicializar la base de datos
        dbHelper = new VehiculoDbHelper(this);

        inicializarVistas();
        configurarRecyclerView();
        // La carga de datos se realizará en onResume para asegurar el refresh.
        configurarListeners();
    }

    private void inicializarVistas() {
        recyclerView = findViewById(R.id.recyclerViewVehiculos);
        fabAgregar = findViewById(R.id.fabAgregar);
        btnMenuDrawer = findViewById(R.id.btnMenuDrawer);
    }

    private void configurarRecyclerView() {
        // Inicializar la lista que será usada por el adaptador
        listaVehiculos = new ArrayList<>();
        adapter = new VehiculoAdapter(this, listaVehiculos);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
    }

    /**
     * Carga la lista de vehículos desde la base de datos.
     * Si la DB está vacía, inserta un conjunto de datos iniciales.
     */
    private void cargarVehiculosDesdeDB() {
        // 1. Obtener la lista de vehículos desde la base de datos
        List<Vehiculo> vehiculosDB = dbHelper.getAllVehiculos();

        // 2. Comprobar si la base de datos está vacía e insertar datos iniciales si es necesario
        if (vehiculosDB.isEmpty()) {
            Log.d("MainActivity", "Base de datos de vehículos vacía. Cargando datos iniciales.");

            // Datos iniciales simulados
            List<Vehiculo> datosIniciales = new ArrayList<>();
            datosIniciales.add(new Vehiculo("ABC123", "Toyota", "Corolla", 2020, "Sedán", "Disponible"));
            datosIniciales.add(new Vehiculo("XYZ789", "Honda", "Civic", 2021, "Sedán", "En Mantenimiento"));
            datosIniciales.add(new Vehiculo("DEF456", "Ford", "Ranger", 2019, "Camioneta", "Disponible"));
            datosIniciales.add(new Vehiculo("GHI321", "Chevrolet", "Spark", 2022, "Hatchback", "Vendido"));

            // Insertar cada vehículo en la base de datos
            for (Vehiculo v : datosIniciales) {
                dbHelper.addVehiculo(v);
            }

            // Volver a leer desde la base de datos después de la inserción inicial
            vehiculosDB = dbHelper.getAllVehiculos();
        }

        // 3. Actualizar la lista del adaptador con los vehículos obtenidos
        listaVehiculos.clear();
        listaVehiculos.addAll(vehiculosDB);

        // 4. Notificar al adaptador que los datos han cambiado
        adapter.notifyDataSetChanged();
    }


    private void configurarListeners() {
        fabAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Iniciar la actividad para agregar un nuevo vehículo
                Intent intent = new Intent(MainActivity.this, AgregarVehiculoActivity.class);
                startActivity(intent);
            }
        });

        btnMenuDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Iniciar la actividad del menú (asumiendo que existe)
                Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Llamar a la función de carga de datos en onResume.
        // Esto es crucial para que la lista se refresque automáticamente
        // cuando se vuelve desde AgregarVehiculoActivity después de guardar.
        cargarVehiculosDesdeDB();
    }
}