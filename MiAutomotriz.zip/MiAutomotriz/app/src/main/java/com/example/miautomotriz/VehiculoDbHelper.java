package com.example.miautomotriz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase ayudante para gestionar la base de datos SQLite de vehículos.
 * Se encarga de la creación, actualización y operaciones CRUD (Crear, Leer, Actualizar, Borrar).
 */
public class VehiculoDbHelper extends SQLiteOpenHelper {

    // --- Constantes de la Base de Datos ---
    private static final String DATABASE_NAME = "vehiculos.db";
    private static final int DATABASE_VERSION = 1;

    // --- Constantes de la Tabla Vehiculos ---
    private static final String TABLE_VEHICULOS = "vehiculos";
    public static final String COLUMN_ID = "_id"; // Es buena práctica usar _id para el ID
    public static final String COLUMN_PLACA = "placa"; // Esta es la Patente
    public static final String COLUMN_MARCA = "marca";
    public static final String COLUMN_MODELO = "modelo";
    public static final String COLUMN_ANIO = "anio";
    public static final String COLUMN_TIPO = "tipo";
    public static final String COLUMN_ESTADO = "estado";

    // --- Sentencia SQL para crear la tabla ---
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_VEHICULOS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_PLACA + " TEXT NOT NULL UNIQUE, " + // Patente es ÚNICA
                    COLUMN_MARCA + " TEXT NOT NULL, " +
                    COLUMN_MODELO + " TEXT NOT NULL, " +
                    COLUMN_ANIO + " INTEGER NOT NULL, " +
                    COLUMN_TIPO + " TEXT, " +
                    COLUMN_ESTADO + " TEXT" +
                    ");";

    /**
     * Constructor de la clase.
     * @param context El contexto de la aplicación.
     */
    public VehiculoDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Se llama cuando la base de datos es creada por primera vez.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("VehiculoDbHelper", "Creando la base de datos y la tabla de vehículos.");
        db.execSQL(TABLE_CREATE);
    }

    /**
     * Se llama cuando la base de datos necesita ser actualizada (nueva versión).
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w("VehiculoDbHelper", "Actualizando la base de datos de la versión " + oldVersion + " a " + newVersion);
        // Política de actualización simple: borrar todo y crear de nuevo
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICULOS);
        onCreate(db);
    }

    /**
     * Agrega un nuevo vehículo a la base de datos.
     * @param vehiculo El objeto Vehiculo a insertar.
     * @return El ID de la nueva fila insertada, o -1 si ocurrió un error.
     */
    public long addVehiculo(Vehiculo vehiculo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Mapea el objeto Vehiculo a las columnas de la DB
        values.put(COLUMN_PLACA, vehiculo.getPatente()); // El objeto usa getPatente()
        values.put(COLUMN_MARCA, vehiculo.getMarca());
        values.put(COLUMN_MODELO, vehiculo.getModelo());
        values.put(COLUMN_ANIO, vehiculo.getAnio());
        values.put(COLUMN_TIPO, vehiculo.getTipo());
        values.put(COLUMN_ESTADO, vehiculo.getEstado());

        // Insertar la nueva fila
        long newRowId = -1;
        try {
            newRowId = db.insertOrThrow(TABLE_VEHICULOS, null, values);
        } catch (android.database.sqlite.SQLiteConstraintException e) {
            Log.e("VehiculoDbHelper", "Error al insertar, la patente ya existe: " + vehiculo.getPatente());
        } catch (Exception e) {
            Log.e("VehiculoDbHelper", "Error al insertar vehículo", e);
        } finally {
            db.close(); // Siempre cerrar la conexión
        }

        return newRowId;
    }

    /**
     * Obtiene todos los vehículos de la base de datos.
     * @return Una lista (List) de objetos Vehiculo.
     */
    public List<Vehiculo> getAllVehiculos() {
        List<Vehiculo> vehiculos = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                COLUMN_ID,
                COLUMN_PLACA,
                COLUMN_MARCA,
                COLUMN_MODELO,
                COLUMN_ANIO,
                COLUMN_TIPO,
                COLUMN_ESTADO
        };

        String sortOrder = COLUMN_MARCA + " ASC"; // Ordenar por marca alfabéticamente

        // La consulta a la base de datos debe estar aquí
        Cursor cursor = db.query(
                TABLE_VEHICULOS,   // La tabla a consultar
                projection,        // Las columnas a devolver
                null,              // Las columnas para la cláusula WHERE
                null,              // Los valores para la cláusula WHERE
                null,              // No agrupar las filas
                null,              // No filtrar por grupos de filas
                sortOrder          // El orden de clasificación
        );

        try {
            if (cursor != null && cursor.moveToFirst()) { // Siempre verifica que el cursor no sea nulo
                do {
                    // Obtenemos los índices de las columnas usando las constantes correctas
                    int patenteIndex = cursor.getColumnIndexOrThrow(COLUMN_PLACA); // Corregido
                    int marcaIndex = cursor.getColumnIndexOrThrow(COLUMN_MARCA);   // Corregido
                    int modeloIndex = cursor.getColumnIndexOrThrow(COLUMN_MODELO); // Corregido
                    int anioIndex = cursor.getColumnIndexOrThrow(COLUMN_ANIO);     // Corregido
                    int tipoIndex = cursor.getColumnIndexOrThrow(COLUMN_TIPO);     // Corregido
                    int estadoIndex = cursor.getColumnIndexOrThrow(COLUMN_ESTADO); // Corregido

                    // Usamos el constructor completo
                    Vehiculo newVehiculo = new Vehiculo(
                            cursor.getString(patenteIndex),
                            cursor.getString(marcaIndex),
                            cursor.getString(modeloIndex),
                            cursor.getInt(anioIndex),
                            cursor.getString(tipoIndex),
                            cursor.getString(estadoIndex)
                    );

                    vehiculos.add(newVehiculo);
                } while(cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e("VehiculoDbHelper", "Error al intentar obtener vehículos de la base de datos", e);
        } finally {
            if (cursor != null) {
                cursor.close(); // Cerrar el cursor es muy importante
            }
            db.close(); // Cerrar la conexión
        }
        return vehiculos;
    }


    /**
     * Elimina un vehículo de la base de datos usando su patente (PK).
     * @param patente La patente (columna PLACA) del vehículo a eliminar.
     */
    public void deleteVehiculo(String patente) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            // El '?' se reemplaza por el valor en el array de String
            db.delete(TABLE_VEHICULOS, COLUMN_PLACA + " = ?", new String[]{patente});
            Log.d("VehiculoDbHelper", "Vehículo eliminado con patente: " + patente);
        } catch (Exception e) {
            Log.e("VehiculoDbHelper", "Error al eliminar vehículo", e);
        } finally {
            db.close();
        }
    }

    // --- Aquí puedes agregar otros métodos si los necesitas ---
    // Por ejemplo: updateVehiculo(Vehiculo vehiculo)
    // O: getVehiculoByPatente(String patente)

}